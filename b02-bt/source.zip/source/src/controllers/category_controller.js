const routerName = 'category'
const renderName = `backend/page/${routerName}/`

const CategoryService = require('../services/category_service')

module.exports = {
    list : async (req , res , next) => {
        let data = await CategoryService.getAll({name : 'vanduy'})
        res.render(`${renderName}list` , {
            items : data
        })
    },
    getForm : async (req , res , next) => { 
        res.render(`${renderName}form` , {})
    }
}
