const CategoryModel = require('../models/category_model')
module.exports = {
    getAll : async (params) => {
       let data =  await CategoryModel.find({})
       return data
    } 
}