const { Schema , model } = require("mongoose")

const CategoryModel = new Schema({
    name : {
        type : String,
    }
}, {
    timestamps : true
}) 

module.exports = model('categories' , CategoryModel)